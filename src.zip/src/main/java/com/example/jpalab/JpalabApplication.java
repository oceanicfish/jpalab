package com.example.jpalab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpalabApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpalabApplication.class, args);
	}
}
